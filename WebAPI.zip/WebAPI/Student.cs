﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI
{
    public class Student
    {

        public int student_id { get; set; }
        public string student_name { get; set; }
        public string student_gender { get; set; }
        public string student_course { get; set; }
        public DateTime student_DOB { get; set; }

    }
}
