﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {

        private static List<Student> students = new List<Student>();

        public StudentController()
        {
            if (students.Count <= 0){
                students.Add(new Student { student_id = 1, student_name = "Meet", student_course = "M.SC.I.C.T.", student_gender = "Male", student_DOB = DateTime.Now});
                students.Add(new Student { student_id = 2, student_name = "MB", student_course = "M.SC.I.T.", student_gender = "Male", student_DOB = DateTime.Now });
            }
        }

        // GET: api/<StudentController>
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return students.ToList();
        }

        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            return students.SingleOrDefault(s => s.student_id == id);
        }

        // POST api/<StudentController>
        [HttpPost]
        public void Post([FromBody] Student newStudent)
        {

            Student studentToAdd = new Student();
            studentToAdd.student_id = newStudent.student_id;
            studentToAdd.student_name = newStudent.student_name;
            studentToAdd.student_course = newStudent.student_course;
            studentToAdd.student_gender = newStudent.student_gender;
            studentToAdd.student_DOB = newStudent.student_DOB;
            students.Add(studentToAdd);
        }

        // PUT api/<StudentController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Student updateStudent)
        {
            Student studentToUpdate = Get(id);
            studentToUpdate.student_name = updateStudent.student_name;
            studentToUpdate.student_gender = updateStudent.student_gender;
            studentToUpdate.student_course = updateStudent.student_course;
            studentToUpdate.student_DOB = updateStudent.student_DOB;

        }

        // DELETE api/<StudentController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            Student studentToDelete = Get(id);
            students.Remove(studentToDelete);
        }
    }
}
